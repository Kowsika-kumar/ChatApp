package org.example.client;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class ChatClient {

    public static void main(String[] args) {
        String host = (args.length > 0) ? args[0] : "localhost";
        int port = (args.length > 1) ? Integer.parseInt(args[1]) : 5555;

        try (Socket socket = new Socket(host, port)) {
            BufferedReader in =
                    new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter out =
                    new PrintWriter(socket.getOutputStream(), true);

            // Reader thread – prints everything the server sends
            Thread reader = new Thread(() -> {
                String msg;
                try {
                    while ((msg = in.readLine()) != null)
                        System.out.println(msg);
                } catch (IOException ignored) {}
            });
            reader.setDaemon(true);
            reader.start();

            // Main thread – reads keyboard input
            Scanner scanner = new Scanner(System.in);
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                out.println(line);
                if ("/quit".equalsIgnoreCase(line.trim())) break;
            }

        } catch (IOException e) {
            System.err.println("Connection error: " + e.getMessage());
        }
    }
}
