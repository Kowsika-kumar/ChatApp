package org.example.server;

import java.io.*;
import java.net.Socket;

public class ClientHandler implements Runnable {

    private final Socket socket;
    private final ChatServer server;
    private BufferedReader in;
    private PrintWriter out;
    private String nickname = "Anonymous";

    public ClientHandler(Socket socket, ChatServer server) {
        this.socket = socket;
        this.server = server;
    }

    @Override
    public void run() {
        try {
            in  = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);

            // Ask for a nickname
            out.println("Enter your nickname:");
            nickname = in.readLine();
            out.println("Welcome, " + nickname + "! Type /quit to exit.");
            server.broadcast("** " + nickname + " joined the chat **", this);

            String line;
            while ((line = in.readLine()) != null) {
                if ("/quit".equalsIgnoreCase(line.trim())) break;
                server.broadcast("[" + nickname + "]: " + line, this);
            }
        } catch (IOException ignored) {
        } finally {
            try {
                socket.close();
            } catch (IOException ignored) {}

            server.remove(this);
            server.broadcast("** " + nickname + " left the chat **", this);
        }
    }

    /** Queues a message to this client. */
    public void send(String msg) {
        out.println(msg);
    }
}
