package org.example.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class ChatServer {

    private final Set<ClientHandler> clients =
            ConcurrentHashMap.newKeySet();

    private final int port;

    public ChatServer(int port) {
        this.port = port;
    }

    public void start() {
        System.out.println("Starting chat server on port " + port + " …");
        try (ServerSocket serverSocket = new ServerSocket(port)) {
            while (true) {
                Socket socket = serverSocket.accept(); // blocks
                ClientHandler handler = new ClientHandler(socket, this);
                clients.add(handler);
                new Thread(handler).start();
            }
        } catch (IOException e) {
            System.err.println("Server error: " + e.getMessage());
        }
    }

    /** Broadcasts a message to every connected client. */
    public void broadcast(String message, ClientHandler sender) {
        for (ClientHandler ch : clients) {
            if (ch != sender) ch.send(message); // don't echo back to sender
        }
    }

    /** Removes a disconnected client from the active set. */
    public void remove(ClientHandler handler) {
        clients.remove(handler);
    }

    public static void main(String[] args) {
        int port = (args.length > 0) ? Integer.parseInt(args[0]) : 5555;
        new ChatServer(port).start();
    }
}
